<?php


$host_name = 'localhost:3307';
$db_user = 'root';
$db_pass = '';
$db_name = 'cit_crud';

$con = mysqli_connect($host_name,$db_user,$db_pass,$db_name);

?>